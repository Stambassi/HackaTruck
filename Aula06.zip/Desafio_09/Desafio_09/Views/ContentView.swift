//
//  ContentView.swift
//  Desafio_09
//
//  Created by Turma02-5 on 26/03/25.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        NavigationStack{
            ZStack {
                Color.corPrimaria.ignoresSafeArea()
                VStack{
                    ScrollView{
                        ZStack{
                            AsyncImageView(urlEntrada: "https://ingresso-a.akamaihd.net/b2b/production/uploads/article/image/330/imagem-pre-venda-ingressos-sessao-especial-3d-harry-potter-e-a-pedra-filosofal-20-anos.jpg")
                                .frame(width: 300, height: 300)
                                .opacity(0.3)
                            //                            .ignoresSafeArea(.all)
                            
                            // background image
                            AsyncImageView(urlEntrada: "https://pa1.aminoapps.com/6608/efc2cc851b4558d4a703a343b4cf613b1cd9acf3_00.gif")
                                .frame(width: 150, height: 150)
                        }
                        
                        ForEach(viewModel.personagens){ personagem in
                            NavigationLink(destination: TemplatePersonagemView(personagem: personagem)){
                                HStack{
                                    // foto
                                    if personagem.image != nil {
                                        AsyncImageView(urlEntrada: personagem.image!)
                                            .frame(width: 100,height: 100)
                                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    }
                                    // nome
                                    if personagem.name != nil {
                                        Text(personagem.name!)
                                            .foregroundStyle(.white)
                                            .padding()
                                    }
                                    Spacer()
                                }.padding()
                            }
                            
                        }
                    }
                }
                
            }.edgesIgnoringSafeArea(.top)
                .onAppear() {
                    viewModel.fetch()
                }
        }
    }
    
}

#Preview {
    ContentView()
}
