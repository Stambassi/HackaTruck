//
//  TemplatePersonagemView.swift
//  Desafio_09
//
//  Created by Turma02-5 on 26/03/25.
//

import SwiftUI

struct TemplatePersonagemView: View {
    @State var personagem : Personagem
    var body: some View {
        ZStack{
            Color.corPrimaria.ignoresSafeArea()
            ScrollView{
                VStack(alignment: .center){
                    // foto
                    if personagem.image != nil {
                        AsyncImageView(urlEntrada: personagem.image!)
                            .frame(width: 200,height: 200)
                            .padding()
                    }
                    // nome
                    if personagem.name != nil {
                        Text(personagem.name!)
                            .foregroundStyle(.white)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .bold()
                            .padding(.top)
                        if personagem.alternate_names != nil {
                            ForEach(personagem.alternate_names!, id: \.self) { outro_nome in
                                Text(outro_nome)
                                    .font(.caption)
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                    
                    Text("Características Físicas")
                        .font(.title2)
                        .foregroundStyle(.white)
                        .bold()
                        .padding(.top)
                    // especie
                    if personagem.species != nil {
                        Text("Espécie: "+personagem.species!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    // genero
                    if personagem.gender != nil {
                        Text("Gênero: "+personagem.gender!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // eye Color
                    if personagem.eyeColor != nil {
                        Text("Cor do olho: "+personagem.eyeColor!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // hair Color
                    if personagem.hairColor != nil {
                        Text("Cor do cabelo: "+personagem.hairColor!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // alive
                    if personagem.alive != nil {
                        Text("Está vivo? "+(personagem.alive! ? "Sim" : "Não"))
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // dateOfBirth
                    if personagem.dateOfBirth != nil {
                        Text("Aniversário: "+personagem.dateOfBirth!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    Text("Características do Universo")
                        .font(.title2)
                        .foregroundStyle(.white)
                        .bold()
                        .padding(.top)
                    
                    // house
                    if personagem.house != nil {
                        Text("Casa: "+personagem.house!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // wizard
                    if personagem.wizard != nil {
                        Text("É um mago? "+(personagem.wizard! ? "Sim" : "Não"))
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // ancestry
                    if personagem.ancestry != nil {
                        Text("Ancestralidade: "+personagem.ancestry!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    // wand
                    if personagem.wand.core != nil && personagem.wand.length != nil && personagem.wand.wood != nil    {
                        let tamanho = String(personagem.wand.length!)
                        Text("Varinha: "+personagem.wand.core!+", "+personagem.wand.wood!+", "+tamanho)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    // patronus
                    if personagem.patronus != nil {
                        Text("Patrono: "+personagem.patronus!)
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    
                    //hogwartsStudent or Staff
                    
                    if personagem.hogwartsStaff != nil || personagem.hogwartsStudent != nil {
                        let tipo : String = (personagem.hogwartsStaff! ? "Staff" : "Estudante")
                        Text("Função: "+tipo)
                            .foregroundStyle(.white)
                            .font(.headline)
                        
                    }
                    
                }.padding()
                
            }
            
        }
    }
}

//#Preview {
//    TemplatePersonagemView()
//}
