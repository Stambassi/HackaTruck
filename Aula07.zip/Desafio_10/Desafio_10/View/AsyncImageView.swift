//
//  AsyncImageView.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import SwiftUI

struct AsyncImageView: View {
    @State var urlEntrada : String
    var body: some View {
        AsyncImage(url: URL(string: urlEntrada)){ image in
            image
                .resizable()
                .aspectRatio(contentMode: .fill)
//                .offset(y:50)
        } placeholder: {
            Image(systemName: "questionmark.diamond")
                .foregroundStyle(.white)
        }    }
}
