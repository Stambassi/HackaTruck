//
//  JogadorFotoView.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import SwiftUI

struct JogadorFotoView: View {
    @State var jogador : Jogador
    var body: some View {
        NavigationLink(destination: JogadorView(jogador: jogador)){
            ZStack{
                VStack(alignment: .center){
                    if jogador.imagem != nil {
                        AsyncImageView(urlEntrada: jogador.imagem!)
                            .frame(width: 80, height: 80)
    //                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .clipShape(Circle().offset(y:-20))

                    }
                    if jogador.apelido != nil {
                        Text(jogador.apelido!)
                            .font(.headline)
                            .foregroundStyle(.white)
                            .offset(y:-20)
                    }
                }.padding(5)
            }
            
        }
    }
}
