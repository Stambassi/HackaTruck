//
//  ViewModel.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import Foundation

let url_api : String = "http://192.168.128.10:1880/"

class ViewModel : ObservableObject {
    
    @Published var exercicios : [Exercicio] = []
    @Published var treinos : [Treino] = []
    
    func fetchExercicios(){
        let url_get_exercicio = url_api+"exercicioGET"
        guard let url = URL(string: url_get_exercicio ) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Exercicio].self, from: data)
                
                DispatchQueue.main.async{
                    self?.exercicios = parsed
                }
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    func fetchTreinos(){
        let url_get_treino = url_api+"treinoGET"
        guard let url = URL(string: url_get_treino ) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Treino].self, from: data)
                
                DispatchQueue.main.async{
                    self?.treinos = parsed
                }
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
