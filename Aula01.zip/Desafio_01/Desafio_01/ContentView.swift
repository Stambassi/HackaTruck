//
//  ContentView.swift
//  Desafio_01
//
//  Created by stambassi on 19/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Rectangle().foregroundColor(.red).frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 100)
                Spacer()
                Rectangle().foregroundColor(.blue).frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 100)
            }.padding()
            Spacer()
            HStack{
                Rectangle().foregroundColor(.green).frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 100)
                Spacer()
                Rectangle().foregroundColor(.yellow).frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 100)
            }.padding()
        }
    }
}

#Preview {
    ContentView()
}
