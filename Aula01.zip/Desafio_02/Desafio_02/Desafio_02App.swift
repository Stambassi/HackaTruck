//
//  Desafio_02App.swift
//  Desafio_02
//
//  Created by Turma02-5 on 19/03/25.
//

import SwiftUI

@main
struct Desafio_02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
