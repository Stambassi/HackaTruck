//
//  Desafio_11App.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import SwiftUI

@main
struct Desafio_11App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
