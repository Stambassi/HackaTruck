//
//  ViewModel.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import Foundation

let url_api : String = "http://192.168.128.10:1880/umidadeGET"

class ViewModel : ObservableObject {
    
    @Published var leituras : [LeituraSensor] = []
    
    func fetch(){
        guard let url = URL(string: url_api) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([LeituraSensor].self, from: data)
                
                DispatchQueue.main.async{
                    self?.leituras = parsed
                }
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
