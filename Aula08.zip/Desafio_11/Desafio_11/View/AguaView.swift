//
//  AguaView.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import SwiftUI

struct AguaView: View {
    @State var umidade : String
    var body: some View {
        ZStack{
            Color.blue.brightness(/*@START_MENU_TOKEN@*/0.60/*@END_MENU_TOKEN@*/)
            HStack{
                Text(umidade)
                    .font(.headline)
                    .padding()
                
                Spacer()
                if(Float(umidade)! > 30.0){
                    Image(systemName: "drop.circle.fill")
                        .foregroundStyle(.blue)
                        .font(.system(size: 30))
                        .padding()
                        
                } else {
                    Image(systemName: "drop.circle.fill")
                        .foregroundStyle(.gray)
                        .font(.system(size: 30))
                        .padding()
                }
                
                
            }
        }
        .frame(width: 200, height: 50)
        .cornerRadius(5.0)
        
    }
}

