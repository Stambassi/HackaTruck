//
//  ContentView.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()

    var body: some View {
        ScrollView{
            ZStack{
                VStack{
                    Text("Sensor de umidade")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                    ForEach(viewModel.leituras, id: \.self){ leitura in
                        if(leitura.umidade != nil){
                            AguaView(umidade: leitura.umidade!)
                        }
                    }
                }
            }
        }
        .onAppear(){
            viewModel.fetch()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
