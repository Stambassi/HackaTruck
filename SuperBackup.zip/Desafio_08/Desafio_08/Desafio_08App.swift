//
//  Desafio_08App.swift
//  Desafio_08
//
//  Created by Turma02-5 on 25/03/25.
//

import SwiftUI

@main
struct Desafio_08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
