//
//  SheetView.swift
//  Desafio_08
//
//  Created by Turma02-5 on 25/03/25.
//

import SwiftUI

struct SheetView: View {
    @Binding var local_atual : Location
    var body: some View {
        ZStack{
            Color.corPrimaria.ignoresSafeArea()
            VStack{
                // Imagem
                AsyncImage(url: URL(string: local_atual.foto)){ image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding()
                } placeholder: {
                    Image(systemName: "questionmark.square")
                        .foregroundStyle(.white)
                }.frame(width: 300, height: 200)
                    .border(.corSecundaria)

                
                
                // Nome
                Text(local_atual.nome)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                    .padding()
                    .foregroundStyle(.corSecundaria)
                
                // Texto
                
                ScrollView{
                    Text(local_atual.descricao)
                        .multilineTextAlignment(.leading)
                }.frame(width: 270, height: 400)
                    .padding()
                    .background(.corSecundaria)
                    .border(.corPrimaria)

                
            }
        }
        
    }
}

#Preview {
    SheetView(local_atual: .constant(Location(longitude: -43.210555555556, latitude: -22.951944444444, nome: "Cristo Redentor", descricao: "Cristo Redentor é uma estátua que retrata Jesus Cristo localizada no topo do morro do Corcovado, a 709 metros acima do nível do mar, dentro do Parque Nacional da Tijuca. Tem vista para parte considerável da cidade brasileira do Rio de Janeiro, sendo a frente da estátua voltada para a Baía de Guanabara e as costas para a Floresta da Tijuca. Feito de concreto armado e pedra-sabão,tem trinta metros de altura (uma das maiores estátuas do mundo), sem contar os oito metros do pedestal, sendo a mais alta estátua do mundo no estilo Art Déco. Seus braços se esticam por 28 metros de largura e a estrutura pesa 1145 toneladas.", foto: "https://upload.wikimedia.org/wikipedia/commons/2/28/Santa_Teresa%2C_Rio_de_Janeiro_-_State_of_Rio_de_Janeiro%2C_Brazil_-_panoramio_%2810%29.jpg")))
}
