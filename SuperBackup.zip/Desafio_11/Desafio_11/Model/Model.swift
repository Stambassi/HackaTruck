//
//  Model.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import Foundation

struct LeituraSensor: Codable, Identifiable {
    let id : Int
    let _id : String?
    let _rev: String?
    let umidade: String?
}
