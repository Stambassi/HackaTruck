//
//  ContentView.swift
//  Desafio_11
//
//  Created by Turma02-5 on 01/04/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()

    var body: some View {
        ZStack{
            VStack{
                ForEach(viewModel.leituras){ leitura in
                    if(leitura.umidade != nil){
                        Text(leitura.umidade!)
                    }
                }
            }
        }
        .onAppear(){
            viewModel.fetch()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
