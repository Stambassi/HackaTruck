//
//  Rosa.swift
//  Desafio_05
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct RosaView: View {
    var body: some View {
        ZStack{
            Color.pink.ignoresSafeArea(edges: .top)
            VStack{
                Image(systemName: "paintbrush")
                    .frame(width: 300,height: 300)
                    .foregroundColor(.pink)
                    .font(.system(size: 200))
                    .background(.black)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)

            }
        }
        
       
    }
}

#Preview {
    ContentView()
}

