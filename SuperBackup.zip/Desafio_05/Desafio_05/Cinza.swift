//
//  Cinza.swift
//  Desafio_05
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct CinzaView: View {
    var body: some View {
        ZStack{
            Color.gray.ignoresSafeArea(edges: .top)
            VStack{
                Image(systemName: "paintpalette")
                    .frame(width: 300,height: 300)
                    .foregroundColor(.gray)
                    .font(.system(size: 200))
                    .background(.black)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)

            }
        }
    }
}

#Preview {
    ContentView()
}
