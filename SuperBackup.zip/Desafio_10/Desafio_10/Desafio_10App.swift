//
//  Desafio_10App.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import SwiftUI

@main
struct Desafio_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
