//
//  ViewModel.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import Foundation

let url_api : String = "http://192.168.128.13:1880/readcarneiro"


class ViewModel : ObservableObject {
    
    @Published var jogadores : [Jogador] = []
    
    func fetch(){
        guard let url = URL(string: url_api) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Jogador].self, from: data)
                
                DispatchQueue.main.async{
                    self?.jogadores = parsed
                }
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
