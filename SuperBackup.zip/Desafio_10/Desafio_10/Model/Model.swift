//
//  Model.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import Foundation

struct Jogador: Codable, Identifiable {
    let _id : String?
    let _rev: String?
    let id : Int
    let nome : String?
    let apelido : String?
    let numero: Int?
    let posicao: String?
    let dataNascimento: String?
    let cidade: String?
    let anoChegada: Int?
    let imagem: String?
}
