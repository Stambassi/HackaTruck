//
//  JogadorView.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import SwiftUI

struct JogadorView: View {
    @State var jogador : Jogador

    var body: some View {
        ScrollView{
            ZStack{
//                LinearGradient(gradient: Gradient(colors: [.white, .black]),startPoint: ., endPoint: .bottom).ignoresSafeArea()
                VStack(alignment: .center){
                    if jogador.imagem != nil {
                        AsyncImageView(urlEntrada: jogador.imagem!)
                            .frame(width: 200, height: 200)
                            .padding(50)
                    }
                    if jogador.apelido != nil {
                        Text(jogador.apelido!)
                            .font(.custom("Numero", size: 50))
                            .bold()
                    }
                    if jogador.numero != nil{
                        Text(String(jogador.numero!))
                            .font(.custom("Numero", size: 100))
                            .bold()
                    }
                    if jogador.nome != nil{
                        Text(jogador.nome!)
                            .font(.title)
                    }
                    if jogador.posicao != nil{
                        Text(jogador.posicao!)
                            .font(.title3)
                    }
                    
                    
                    
                    
                    
                }
            }
            
        }
        
        
    }
}
