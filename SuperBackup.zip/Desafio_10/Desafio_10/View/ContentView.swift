//
//  ContentView.swift
//  Desafio_10
//
//  Created by Turma02-5 on 27/03/25.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()

    var body: some View {
        NavigationStack{
            ZStack{
                AsyncImageView(urlEntrada: "https://www.miltonandking.com/wp-content/uploads/2018/10/Wallpaper-IngridMika-BWStripe-1.jpg")
                    .frame(width: 400, height: .infinity).ignoresSafeArea()
                
                VStack{
                    Text("Atlético Mineiro")
                        .font(.title)
                        .bold()
                        .padding(50)
                        .frame(width: 350, height: 70)
                        .background(.white)
                        .cornerRadius(10)
                    ZStack{
                        AsyncImageView(urlEntrada: "https://i.pinimg.com/736x/67/86/29/67862923ea5e88b429156ec0fa187b5d.jpg")
                            .frame(width: 380, height: 360)
                        
                        VStack{
                            HStack{
                                VStack{
                                    ForEach(viewModel.jogadores){ jogador in
                                        if jogador.posicao != nil {
                                            if jogador.posicao! == "Ponta Esquerda"{
                                                JogadorFotoView(jogador: jogador)
                                            }
                                        }
                                    }
                                }
                                VStack{
                                    ForEach(viewModel.jogadores){ jogador in
                                        if jogador.posicao != nil {
                                            if jogador.posicao! == "Atacante"{
                                                JogadorFotoView(jogador: jogador)
                                            }
                                        }
                                    }
                                }
                                VStack{
                                    ForEach(viewModel.jogadores){ jogador in
                                        if jogador.posicao != nil {
                                            if jogador.posicao! == "Ponta Direita"{
                                                JogadorFotoView(jogador: jogador)
                                            }
                                        }
                                    }
                                }
                            }
                            
                            HStack {
                                ForEach(viewModel.jogadores){ jogador in
                                    if jogador.posicao != nil {
                                        if jogador.posicao! == "Meia Atacante"{
                                            JogadorFotoView(jogador: jogador)
                                        }
                                    }
                                }
                                
                            }
                            
                            HStack {
                                ForEach(viewModel.jogadores){ jogador in
                                    if jogador.posicao != nil {
                                        if jogador.posicao! == "Volante"{
                                            JogadorFotoView(jogador: jogador)
                                        }
                                    }
                                }
                            }
                            
                            HStack{
                                VStack{
                                    ForEach(viewModel.jogadores){ jogador in
                                        if jogador.posicao != nil {
                                            if jogador.posicao! == "Lateral Esquerdo"{
                                                JogadorFotoView(jogador: jogador)
                                            }
                                        }
                                    }
                                }
                                ForEach(viewModel.jogadores){ jogador in
                                    if jogador.posicao != nil {
                                        if jogador.posicao! == "Zagueiro"{
                                            JogadorFotoView(jogador: jogador)
                                        }
                                    }
                                }
                                VStack{
                                    ForEach(viewModel.jogadores){ jogador in
                                        if jogador.posicao != nil {
                                            if jogador.posicao! == "Lateral Direito"{
                                                JogadorFotoView(jogador: jogador)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
           
            }
        }
        .onAppear() {
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
