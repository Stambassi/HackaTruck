//
//  ContentView.swift
//  Desafio_02
//
//  Created by stambassi on 19/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isRotating = 0.0
    @State private var stateImage = false
    var body: some View {
        
        HStack {
//            Button(action: {
//                while(stateImage){
//                    isRotating+=10
//                }
//                    }) {
//                        Image("Image")
//                        .resizable()
//                        .frame(width: 150, height: 150)
//                        .scaledToFit()
//                        .clipShape(Circle())
//                        .rotationEffect(.degrees(isRotating))
//                    }
            //Spacer()
            Image("Image")
                .resizable()
                .frame(width: 150, height: 150)
                .scaledToFit()
                .clipShape(Circle())
                .rotationEffect(.degrees(70.0))
//                .cornerRadius(100)
            Spacer()
            VStack(spacing:10){
                Text("HackaTruck")
                    .font(.caption)
                    .foregroundStyle(.red)
                    .bold()
                Text("77 Universidades")
                    .font(.caption)
                    .foregroundStyle(.blue)
                    .italic()
                Text("5 regiões do Brasil")
                    .font(.caption)
                    .foregroundStyle(.yellow)
                    .underline()
            }
            Spacer()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
