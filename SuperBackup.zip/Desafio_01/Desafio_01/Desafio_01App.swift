//
//  Desafio_01App.swift
//  Desafio_01
//
//  Created by Turma02-5 on 19/03/25.
//

import SwiftUI

@main
struct Desafio_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
