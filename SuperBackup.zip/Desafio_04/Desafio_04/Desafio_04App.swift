//
//  Desafio_04App.swift
//  Desafio_04
//
//  Created by Turma02-5 on 20/03/25.
//

import SwiftUI

@main
struct Desafio_04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
