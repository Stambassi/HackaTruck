//
//  ContentView.swift
//  Desafio_04
//
//  Created by stambassi on 20/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var distancia = 0.00
    @State private var tempo = 0.00
    @State private var velocidade = 0.00
    @State private var imgAtual = "Interrogacao"
    @State private var corAtual : Color = .gray
    
    let animais : [String] = ["Tartaruga", "Elefante", "Avestruz", "Leao", "Guepardo"]
    let intervalos: [[String : Double]] = [
        ["inicio":0,"fim":9.9],
        ["inicio":10,"fim":29.9],
        ["inicio":30,"fim":69.9],
        ["inicio":70,"fim":89.9],
        ["inicio":90,"fim":130],
    ]
    let colors : [Color] = [.brat, .marromBosta, .azul, .roxo, .amarelo]
    let corPadrao : Color = .gray
    let imgPadrao = "Interrogacao"
    func calcularVelocidade (distancia: Double, tempo: Double ) -> Double {
        return Double(distancia/tempo)
    }
   

    var body: some View {
        ZStack{
            Rectangle().fill(corAtual).ignoresSafeArea()
            VStack {
                Text("Digite a distância (km): ")
                TextField(String(distancia), value:$distancia, format:.number)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .multilineTextAlignment(.center)
                    .frame(width: 200, height: 20)
                    .padding(5.0)
                    .background(Color.white)
                    .cornerRadius(15.0)
                
                
                Text("Digite o tempo (h): ")
                TextField(String(tempo), value:$tempo, format:.number)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .multilineTextAlignment(.center)
                    .frame(width: 200, height: 20)
                    .padding(5.0)
                    .background(Color.white)
                    .cornerRadius(15.0)
                
                Button(action: {
                    velocidade = calcularVelocidade(distancia:distancia,tempo:tempo)
                    var i = 0
                    for intervalo in intervalos {
                        let inicio = Double(intervalo["inicio"]!)
                        let fim = Double(intervalo["fim"]!)
                        print(inicio)
                        print(fim)
                        if inicio <= velocidade && velocidade <= fim{
                            imgAtual = animais[i]
                            corAtual = colors[i]
                        }
                        i += 1
                    }
                    let inicio = Double(intervalos[0]["inicio"]!)
                    let fim = Double(intervalos[intervalos.count - 1]["fim"]!)
                    if velocidade < inicio || fim < velocidade {
                        imgAtual = imgPadrao
                        corAtual = corPadrao
                    }
                    
                    
                      }) {
                        Text("Calcular")
                              .padding(8.0)
                              .background(Color.black)
                              .foregroundStyle(Color.purple)
                              .cornerRadius(10.0)
                      }
                    
                
                Spacer()
                Text("\(String(format: "%.2f",velocidade)) km/h")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                
                Image(imgAtual)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 250, height: 250)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                Spacer()
                HStack{
                    VStack(spacing:10){
                        ForEach(animais, id:\.self){ animal in
                            Text(animal)
                                .foregroundStyle(Color.white)
                                .font(.headline)
                        }
                    }
                    VStack(spacing:10){
                        ForEach(intervalos, id:\.self){intervalo in
                            let inicio = String(intervalo["inicio"]!)
                            let fim = String(intervalo["fim"]!)
                            Text("(\(inicio) - \(fim)km/h)")
                                .foregroundStyle(Color.white)
                                .font(.headline)
                        }
                    }
                    VStack(spacing:10){
                        ForEach(colors, id:\.self){ color in
                            Circle()
                                .fill(color)
                                .frame(width: 20, height: 20)
                        }
                        
                    }
                    
                }.frame(width: 300, height: 200)
                    .background(Color.black)
                    .cornerRadius(15.0)
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
