//
//  Modo1.swift
//  Desafio_06
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct Modo1View: View {
    var body: some View {
        ZStack{
            Color.fundo.ignoresSafeArea()
            VStack{
                Text("Modo 1")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundStyle(.white)
                    .bold()
                    .padding()
                
                Spacer()
                
                VStack{
                    Text("Nome: Augusto")
                        .foregroundStyle(.white)
                        .font(.title2)
                    Text("Sobrenome: Stambassi")
                        .foregroundStyle(.white)
                        .font(.title2)
                }
                .frame(width: 250,height: 150)
                .background(.pink)
                .cornerRadius(10.0)

            
                Spacer()
                
            }
        }
    }
}

#Preview {
    Modo1View()
}
