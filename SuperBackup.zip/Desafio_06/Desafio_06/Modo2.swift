//
//  Modo2.swift
//  Desafio_06
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct Modo2View: View {
    @State private var nome : String = ""
    var body: some View {
        NavigationStack{
            ZStack{
                Color.fundo.ignoresSafeArea()
                VStack{
                    Text("Modo 2")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundStyle(.white)
                        .padding()
                        .bold()
                    
                    Spacer()
                    
                    VStack{
                        TextField("Digite seu nome aqui", text: $nome)
                            .padding()
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white)
                        Text("Bem vindo, \(nome)")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                        
                        Spacer()
                        NavigationLink(destination: Modo2bView(nome:$nome)){
                            Text("Acessar tela")
                                .foregroundStyle(.white)
                                .frame(width: 120, height: 50)
                                .background(.blue)
                                .cornerRadius(10.0)
                                .bold()
                                .padding()
                        }
                    }
                    .frame(width: 350, height: 250)
                    .background(.pink)
                    .cornerRadius(10.0)
                    
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    Modo2View()
}
