//
//  Desafio_03App.swift
//  Desafio_03
//
//  Created by Turma02-5 on 19/03/25.
//

import SwiftUI

@main
struct Desafio_03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
