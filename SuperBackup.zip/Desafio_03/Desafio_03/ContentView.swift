//
//  ContentView.swift
//  Desafio_03
//
//  Created by stambassi on 19/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var nome = ""
    @State private var showingAlert: Bool = false
    var body: some View {
        ZStack{
            Image("Gato")
                .resizable()
                .scaledToFill()
                .opacity(0.15)
                .blur(radius: 5.0)
                .saturation(0.5)
            VStack{
                Text ("Bem vindo, \(nome)")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                
                TextField("Digite seu nome aqui", text: $nome)
                    .padding()
                    .multilineTextAlignment(.center)
                
                Spacer()
                
                Image("Gato2")
                    .resizable()
                    .frame(width: 250, height: 200)
                    .scaledToFit()
                
                Spacer()
                
//                TextField("Entre ")
                
                Button("Entrar"){
                    showingAlert = true
                }
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("ALERTA!").bold(), message: Text("Você irá iniciar o desafio da aula agora"), dismissButton: .default(Text("Vamos lá!")))
                    }
                
                
            }
        }
    }
}

#Preview {
   ContentView()
}
