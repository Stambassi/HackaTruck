//
//  AsyncImageView.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import SwiftUI

struct AsyncImageView: View {
    @State var urlEntrada : String
    var body: some View {
        AsyncImage(url: URL(string: urlEntrada)){ image in
            image
                .resizable()
                .aspectRatio(contentMode: .fill)
        } placeholder: {
            Image(systemName: "questionmark.diamond")
                .foregroundStyle(.white)
        }
    }
}

//#Preview {
//    AsyncImageView()
//}
