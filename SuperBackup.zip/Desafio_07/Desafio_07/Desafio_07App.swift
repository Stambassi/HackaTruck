//
//  Desafio_07App.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import SwiftUI

@main
struct Desafio_07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
