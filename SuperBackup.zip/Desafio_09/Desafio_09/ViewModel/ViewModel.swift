//
//  ViewModel.swift
//  Desafio_09
//
//  Created by Turma02-5 on 26/03/25.
//

import Foundation

let url_api : String = "https://hp-api.onrender.com/api/characters"


class ViewModel : ObservableObject {
    
    @Published var personagens : [Personagem] = []
    
    func fetch(){
        guard let url = URL(string: url_api) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Personagem].self, from: data)
                
                DispatchQueue.main.async{
                    self?.personagens = parsed
                }
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
}
