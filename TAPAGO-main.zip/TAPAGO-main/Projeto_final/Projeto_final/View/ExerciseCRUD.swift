//
//  ExerciseCRUD.swift
//  Projeto_final
//
//  Created by Turma02-3 on 04/04/25.
//

import SwiftUI

struct ExerciseCRUD: View {
    
    @State var nomeEx: String = ""
    
    @State var duracaoEx: Int = 0
    
    enum Reps: String, CaseIterable, Identifiable {
        case ateFalha, um, dois, tres, quatro, cinco, seis, sete, oito, nove, dez, onze, doze, treze, quatorze, quinze, dezesseis, dezessete, dezoito, dezenove, vinte
        var id: Self { self }
    }

    @State private var selectedReps: Int = 0
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        ZStack {
            Color(.primaryPreset)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack {
                Text("Personalizar Exercicio")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "figure.strengthtraining.traditional")
                    .resizable()
                    .frame(width: 250, height: 250)
                    .foregroundColor(.white)
                    .background(.navBar)
                    .cornerRadius(10)
                Spacer()
                HStack {
                    Text("Nome:")
                        .foregroundColor(.white)
                        .font(.title2)
                    Spacer()
                    TextField("Nomeie o exercício", text: $nomeEx)
                        .textFieldStyle(.roundedBorder)
                        .padding(.leading)
                        .frame(width: 200)
                        .multilineTextAlignment(TextAlignment.center)
                }
                .padding(35)
                .frame(width: 370, height: 55)
                .background(.navBar)
                .cornerRadius(10)
                .padding(35)
                HStack {
                    Text("Repetições")
                        .foregroundColor(.white)
                        .font(.title2)
                    Spacer()
                    Picker(selection: $selectedReps, label: Text("Picker")) {
                        Text("Ate a Falha!").tag(0)
                        ForEach(1..<21){
                            Text(String($0)).tag($0)
                        }
                    }
                    .onChange(of: selectedReps) { tag in print("Color tag: \(tag)") }
                    .tint(.white)
                }
                .padding(35)
                .padding(.bottom, 0)
                .frame(width: 370, height: 55)
                .background(.navBar)
                .cornerRadius(10)
                HStack {
                    Text("Descanso:")
                        .foregroundColor(.white)
                        .font(.title2)
                    Spacer()
                    TextField("Enter your TimeBreak", value: $duracaoEx, format: .number)
                        .textFieldStyle(.roundedBorder)
                        .padding(.leading)
                        .frame(width: 75)
                        .multilineTextAlignment(TextAlignment.center)
                    Text("segundos.")
                        .foregroundColor(.white)
                        .font(.title2)
                }
                .padding(35)
                .frame(width: 370, height: 55)
                .background(.navBar)
                .cornerRadius(10)
                .padding(35)
                Spacer()
                HStack {
                    Button("Adcionar Exercicio", action: { 
                        let novoExercicio = Exercicio(_id:"",_rev:"",id: viewModel.exercicios.count + 1, nome: nomeEx, musculo: "Peito", image: "figure.strengthtraining.traditional", categoria: "Musculação", tempoPorRep: 3, peso: [0], repeticao: selectedReps, descansoPorRep: duracaoEx)
                        print(novoExercicio)
                        viewModel.postExercicio(exercicio: novoExercicio)
                    })
                        .foregroundColor(.white)
                        .frame(width: 150, height: 40)
                        .background(.secondaryPreset)
                        .cornerRadius(10)
                }.padding()
                Spacer()
            }
        }
    }
}

#Preview {
    ExerciseCRUD()
}
