//
//  HomePage.swift
//  Projeto_final
//
//  Created by Turma02-25 on 04/04/25.
//

import SwiftUI

struct HomePage: View {
    var body: some View {
        Color(.primaryPreset)
            .ignoresSafeArea()
    }
}

#Preview {
    HomePage()
}
