//
//  ContentView.swift
//  Desafio_08
//
//  Created by Turma02-5 on 25/03/25.
//

import SwiftUI
import MapKit

struct Location: Hashable{
    let longitude : Double
    let latitude : Double
    let nome : String
    let descricao : String
    let foto : String
}

let locais : [Location] = [
    Location(longitude: -43.210555555556, latitude: -22.951944444444, nome: "Cristo Redentor", descricao: "Cristo Redentor é uma estátua que retrata Jesus Cristo localizada no topo do morro do Corcovado, a 709 metros acima do nível do mar, dentro do Parque Nacional da Tijuca. Tem vista para parte considerável da cidade brasileira do Rio de Janeiro, sendo a frente da estátua voltada para a Baía de Guanabara e as costas para a Floresta da Tijuca. Feito de concreto armado e pedra-sabão, tem trinta metros de altura (uma das maiores estátuas do mundo), sem contar os oito metros do pedestal, sendo a mais alta estátua do mundo no estilo Art Déco. Seus braços se esticam por 28 metros de largura e a estrutura pesa 1145 toneladas. O monumento é um santuário católico e a Arquidiocese do Rio de Janeiro administra a estátua e a capela localizada dentro do seu pedestal, além de também ser responsável pelas celebrações e manutenção do conjunto. O direito de gerenciar a estátua foi concedido pela União à Arquidiocese do Rio na década de 1930, mas o acesso à estátua e a administração do platô onde ela se localiza são realizados pelo Parque Nacional da Tijuca, uma Unidade de Conservação federal gerida pelo Instituto Chico Mendes de Conservação da Biodiversidade (ICMBio).", foto: "https://upload.wikimedia.org/wikipedia/commons/2/28/Santa_Teresa%2C_Rio_de_Janeiro_-_State_of_Rio_de_Janeiro%2C_Brazil_-_panoramio_%2810%29.jpg"),
    Location(longitude: 78.042068, latitude: 27.173891, nome: "Taj Mahal", descricao: " O Taj Mahal (em hindi: ताज महल) é um mausoléu situado em Agra, na Índia, sendo o mais conhecido dos monumentos do país. Encontra-se classificado pela UNESCO como Patrimônio da Humanidade. Foi anunciado em 2007 como uma das sete maravilhas do mundo moderno. A obra foi feita entre 1632 e 1653 com a força de cerca de 20 mil homens, trazidos de várias cidades do Oriente, para trabalhar no suntuoso monumento de mármore branco que o imperador Shah Jahan mandou construir em memória de sua esposa favorita, Aryumand Banu Begam, a quem chamava de Mumtaz Mahal ('A joia do palácio'). Ela morreu após dar à luz o 14.º filho, tendo o Taj Mahal sido construído sobre seu túmulo, junto ao rio Yamuna.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Taj_Mahal_N-UP-A28-a.jpg/320px-Taj_Mahal_N-UP-A28-a.jpg"),
    Location(longitude: -72.545128, latitude: -13.163068, nome: "Machu Picchu", descricao: "Huayna Picchu Picchu ou Machu Picchu (em quíchua Machu Picchu, 'velha montanha'),também chamada 'cidade perdida dos Incas', é uma cidadela Inca, da Era pré-colombiana, bem conservada, localizada no topo de uma montanha, a 2 400 metros de altitude, no vale do rio Urubamba, atual Peru. Foi construída como no início do século XV, por volta de 1420, sob as ordens de Pachacuti. O local é, provavelmente, o símbolo mais típico do Império Inca, quer devido à sua original localização e características geológicas, quer devido à sua descoberta tardia em 1911. Apenas cerca de 30% da cidade é de construção original, o restante foi reconstruído. As áreas reconstruídas são facilmente reconhecidas, pelo encaixe entre as pedras. A construção original é formada por pedras maiores, e com encaixes com pouco espaço entre as rochas.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Sunset_across_Machu_Picchu.jpg/250px-Sunset_across_Machu_Picchu.jpg"),
    Location(longitude: -88.568889, latitude: 20.678333, nome: "Chichén Itzá", descricao: "Chichén Itzá (do iucateque: Chi'ch'èen Ìitsha) Pronúncia original em Yucatec Maya foi uma grande cidade pré-colombiana construída pela civilização maia no final do período clássico. O sítio arqueológico está localizado no município de Tinum, no estado de Yucatán, México. Chichén Itzá era um polo urbano importante dos maias na planície norte no início (600-900) e no final (cerca 800-900) do período clássico e também no início do período pós-clássico (cerca de 900-1200). O local exibe vários estilos arquitetônicos, reminiscentes dos estilos vistos no México central. Acreditava-se que a presença de estilos desta região era sinal da migração direta ou mesmo da conquista do México central, mas a maioria de interpretações contemporâneas veem a presença destes estilos não maias mais como o resultado da difusão cultural.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Chichen_Itza-18_%28cropped%29.jpg/330px-Chichen_Itza-18_%28cropped%29.jpg"),
    Location(longitude: 12.492231, latitude: 41.890209, nome: "Coliseu", descricao: "Coliseu (em italiano: Colosseo), também conhecido como Anfiteatro Flaviano (em latim: Amphitheatrum Flavium; em italiano: Anfiteatro Flavio), é um anfiteatro oval localizado no centro da cidade de Roma, capital da Itália. Construído com tijolos revestidos de argamassa e areia, e originalmente cobertos com travertino é o maior anfiteatro já construído e está situado a leste do Fórum Romano. A construção começou sob o governo do imperador Vespasiano em 72 d.C. e foi concluída em 80 d.C., sob o regime do seu sucessor e herdeiro, Tito. Outras modificações foram feitas durante o reinado de Domiciano (81-96).Estes três imperadores são conhecidos como a dinastia flaviana e o anfiteatro foi nomeado em latim desta maneira por sua associação com o nome da família (Flavius).", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/250px-Colosseo_2020.jpg"),
    Location(longitude: 35.444832, latitude: 30.328960, nome: "Petra", descricao: "Petra (do grego πέτρα, petra; árabe: البتراء, Al-Bitrā/Al-Batrā), originalmente conhecida pelos nabateus como Raqmu, é uma cidade histórica e arqueológica localizada no sul da Jordânia. A cidade é famosa por sua arquitetura esculpida em rocha e por seu sistema de canalização de água. Outro nome para Petra é Cidade Rosa, devido à cor das pedras do local. Estabelecido possivelmente já em 312 a.C. como a capital dos árabes nabateus, é um símbolo jordaniano, assim como a atração turística a mais visitada do país. Os nabateus eram árabes nômades que aproveitaram a proximidade de Petra com as rotas comerciais regionais para estabelecê-la como um importante centro comercial. Os nabateus também são conhecidos por sua grande habilidade na construção de métodos eficientes de coleta de água em desertos áridos e seu talento em esculpir estruturas em rochas sólidas.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Al_Khazneh_Petra_edit_2.jpg/220px-Al_Khazneh_Petra_edit_2.jpg"),
    Location(longitude: 116.570374, latitude: 40.431908, nome: "Muralha da China", descricao: "Grande Muralha da China é uma série de fortificações feitas de pedra, tijolo, terra compactada, madeira e outros materiais, geralmente construída ao longo de uma linha leste-oeste através das fronteiras históricas do norte da China para proteger os Estados e impérios chineses contra as invasões dos vários grupos nômades das estepes da Eurásia, principalmente os mongóis. Várias muralhas estavam sendo construídas já no século VII a.C., que mais tarde foram unidas e tornadas maiores e mais fortes, no que agora é referido como a Grande Muralha.[2] Especialmente famosa é a muralha construída entre 220 e 206 a.C. por Qin Shi Huang, o primeiro Imperador da China. Pouco desta muralha permanece nos dias atuais. Desde então, a Grande Muralha foi reconstruída, mantida e melhorada; a maior parte do trecho existente é da dinastia Ming (1368-1644). Outras finalidades da Grande Muralha incluíram controles de fronteira, permitindo a imposição de direitos sobre mercadorias transportadas ao longo da Rota da Seda, a regulação ou o encorajamento do comércio e do controle da imigração e da emigração. Além disso, as características defensivas da Grande Muralha foram reforçadas pela construção de torres de vigia, quartéis de tropas, estações de guarnição, capacidade de sinalização por meio de fumaça ou fogo e o fato de que o caminho da Grande Muralha também servia como um corredor de transporte.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/The_Great_Wall_of_China_at_Jinshanling.jpg/300px-The_Great_Wall_of_China_at_Jinshanling.jpg"),
    Location(longitude: 31.131302, latitude: 29.976480, nome: "Necrópole de Gizé", descricao: "Necrópole de Gizé (em árabe: جيزة يسروبوليس), também chamada de Pirâmides de Gizé, Guizé ou Guisa, é um sítio arqueológico localizado no planalto de Gizé, nos arredores do Cairo, Egito. Este complexo de monumentos antigos inclui os três complexos de pirâmides conhecidas como as Grandes Pirâmides, a escultura maciça conhecida como a Grande Esfinge, vários cemitérios, uma vila operária e um complexo industrial. A palavra pirâmide não provém da língua egípcia. Formou-se a partir do grego 'pyra' (que quer dizer fogo, luz, símbolo) e 'midos' (que significa medidas). A necrópole está localizada a cerca de 9 km do interior do deserto para a cidade velha de Gizé, no Nilo, e cerca de 25 km a sudoeste do centro da cidade do Cairo, no local da antiga cidade egípcia de Mênfis. As pirâmides, que sempre tiveram grande importância como emblemas do antigo Egito no imaginário ocidental, foram popularizadas nos tempos helenísticos, quando a Grande Pirâmide foi listada por Antípatro de Sídon como uma das Sete Maravilhas do Mundo. É, de longe, a mais antiga das maravilhas do mundo antigo e a única que ainda existe.", foto: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/All_Gizah_Pyramids.jpg/300px-All_Gizah_Pyramids.jpg")
]

struct ContentView: View {
    @State private var local_atual : Location = locais[0]
    @State private var position = MapCameraPosition.region(MKCoordinateRegion(center:CLLocationCoordinate2D(latitude: -14.2350, longitude: -51.9253) , span: MKCoordinateSpan(latitudeDelta: 160, longitudeDelta: 160)))
    @State var shouldPresentSheet = false
    @State var aux = Location(longitude: -43.210555555556, latitude: -22.951944444444, nome: "Cristo Redentor", descricao: "Cristo Redentor é uma estátua que retrata Jesus Cristo localizada no topo do morro do Corcovado, a 709 metros acima do nível do mar, dentro do Parque Nacional da Tijuca. Tem vista para parte considerável da cidade brasileira do Rio de Janeiro, sendo a frente da estátua voltada para a Baía de Guanabara e as costas para a Floresta da Tijuca. Feito de concreto armado e pedra-sabão,tem trinta metros de altura (uma das maiores estátuas do mundo), sem contar os oito metros do pedestal, sendo a mais alta estátua do mundo no estilo Art Déco. Seus braços se esticam por 28 metros de largura e a estrutura pesa 1145 toneladas.", foto: "https://upload.wikimedia.org/wikipedia/commons/2/28/Santa_Teresa%2C_Rio_de_Janeiro_-_State_of_Rio_de_Janeiro%2C_Brazil_-_panoramio_%2810%29.jpg")
    
    var body: some View {
        ZStack {
            Map(position: $position){
                ForEach(locais, id: \.self){ local in
                    Annotation(local.nome, coordinate: CLLocationCoordinate2D(latitude: local.latitude, longitude: local.longitude)){
                        Button {
                            shouldPresentSheet.toggle()
                            aux = local
                            print(shouldPresentSheet)
                            print(aux.nome)
                        } label: {
                            Image(systemName: "pin.fill")
                                .foregroundStyle(.black)
                        }.sheet(isPresented: $shouldPresentSheet) {
                            SheetView(local_atual: $aux)
                        }
                    }
                }
            }.ignoresSafeArea()
            VStack{
                Picker("Escolha uma Maravilha do mundo", selection: $local_atual){
                    ForEach(locais, id: \.self){ local in
                        Text(local.nome)
                    }
                }.onChange(of: local_atual){
                    withAnimation{
                        position = MapCameraPosition.region(MKCoordinateRegion(center:CLLocationCoordinate2D(latitude: local_atual.latitude, longitude: local_atual.longitude) , span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)))
                    }
                }.frame(width: 200, height: 50)
                    .background(.corPrimaria)
                    .cornerRadius(15.0)
                    .tint(.black)
                    .padding()
                Spacer()
                
                Text("Maravilhas do Mundo Moderno")
                    .frame(width: 275, height: 50)
                    .background(.corPrimaria)
                    .cornerRadius(15.0)
                    .padding()
            }
        }
    }
}

#Preview {
    ContentView()
}
