//
//  ContentView.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import SwiftUI


struct Song : Identifiable {
    var id : Int
    var name : String
    var artist : String
    var capa : String
}

struct Config : Identifiable {
    var id : Int
    var name : String
    var image : String
    var author : String
    var authorIcon : String
}

var all_playlists : [[Song]] = [
    [
        Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"),
        Song(id: 1, name: "Babydoll", artist: "Dominic Fike", capa: "https://i.scdn.co/image/ab67616d000048517b1b6f41c1645af9757d5616"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "https://i.scdn.co/image/ab67616d000048515c53799f473fa3e1a48c00ed"),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://i.scdn.co/image/ab67616d0000485142bd9933dbf460dc7c8d3f07"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://i.scdn.co/image/ab67616d000048512737f5b299df632c49bc2e9b"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://i.scdn.co/image/ab67616d000048514a31b146c7cf07705d912efe"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://i.scdn.co/image/ab67616d000048516e996745f2c7b8036abef213"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://i.scdn.co/image/ab67616d000048515c53799f473fa3e1a48c00ed"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://i.scdn.co/image/ab67616d000048514ae1c4c5c45aabe565499163"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://i.scdn.co/image/ab67616d00004851bce3aa89843c02d06c1c9fee"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://i.scdn.co/image/ab67616d000048514ae1c4c5c45aabe565499163"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://i.scdn.co/image/ab67616d00004851c1783b85101ebf6d41a2dcbf"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://i.scdn.co/image/ab67616d00004851c1783b85101ebf6d41a2dcbf"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://i.scdn.co/image/ab67616d0000485132c3e6379f21f21d9c3d3900"),
    ],
    [
        Song(id: 0, name: "Ser bandido é bom demais", artist: "Dj Ramon Sucesso, Mc Kaio", capa: "https://picsum.photos/256"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://picsum.photos/256"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://picsum.photos/256"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://picsum.photos/256"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://picsum.photos/256"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://picsum.photos/256"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://picsum.photos/256"),
    ],
    [
        Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://picsum.photos/256"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://picsum.photos/256"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://picsum.photos/256"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://picsum.photos/256"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://picsum.photos/256"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://picsum.photos/256"),
    ]]


var sugeridos : [Config] = [Config(id: 0, name:"Indie & Metal", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
    Config(id: 1, name:"RAVE FUNK", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
    Config(id: 2, name:"Tudo", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
]

struct ContentView: View {
    var body: some View {
        TemplatePlaylistView(playlist: all_playlists[0], playlist_config: sugeridos[0])
    }
}

#Preview {
    ContentView()
}
