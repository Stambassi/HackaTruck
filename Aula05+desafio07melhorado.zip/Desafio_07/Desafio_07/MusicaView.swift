//
//  MusicaView.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import Foundation

import SwiftUI
struct MusicaView : View {
    @State var musica : Song
    
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.purple, .black]),startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            
            VStack(alignment:.center){
                Spacer()
                AsyncImageView(urlEntrada: musica.capa)
                    .frame(width: 200, height: 200)
                Text(musica.name)
                    .font(.title)
                    .foregroundStyle(.white)
                Text(musica.artist)
                    .font(.headline)
                    .foregroundStyle(.white)
                
                Spacer()
                
                HStack{
                    Image(systemName: "shuffle")
                        .resizable()
                        .frame(width: 30,height: 30)
                        .padding()
                    Image(systemName: "backward.end.fill")
                        .resizable()
                        .frame(width: 30,height: 30)
                        .padding()
                    Image(systemName: "play.fill")
                        .resizable()
                        .frame(width: 30,height: 30)
                        .padding()
                    Image(systemName: "forward.end.fill")
                        .resizable()
                        .frame(width: 30,height: 30)
                        .padding()
                    Image(systemName: "repeat")
                        .resizable()
                        .frame(width: 30,height: 30)
                        .padding()


                }
                .padding(.top)
                .foregroundStyle(.white)
                
                Spacer()
                    
            }
            
            }
        }
    }



#Preview {
    MusicaView(musica:Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"))
}
