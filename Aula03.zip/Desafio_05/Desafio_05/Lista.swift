//
//  Lista.swift
//  Desafio_05
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct Item: Identifiable {
    var id = UUID()
    var nome: String
    var icone: String
}


struct ListaView: View {
    let itens = [
        Item(nome: "nome", icone: "paintbrush"),
        Item(nome: "nome", icone: "paintbrush.pointed"),
        Item(nome: "nome", icone: "paintpalette")
    ]
    
    var body: some View {
        NavigationView{
//            VStack{
                List(itens){ i in
                    HStack{
                        Text(i.nome)
                        Spacer()
                        Image(systemName: i.icone)
                        }
                    }
//                }
            
        }
        
    }
}


#Preview {
    ListaView()
}
