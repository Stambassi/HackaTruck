//
//  Azul.swift
//  Desafio_05
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct AzulView: View {
    var body: some View {
        ZStack{
            Color.blue.ignoresSafeArea(edges: .top)
            VStack{
                Image(systemName: "paintbrush.pointed")
                    .frame(width: 300,height: 300)
                    .foregroundColor(.blue)
                    .font(.system(size: 200))
                    .background(.black)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)

            }
        }
    }
}

#Preview {
    ContentView()
}
