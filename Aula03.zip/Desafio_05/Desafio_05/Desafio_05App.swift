//
//  Desafio_05App.swift
//  Desafio_05
//
//  Created by Turma02-5 on 21/03/25.
//

import SwiftUI

@main
struct Desafio_05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
