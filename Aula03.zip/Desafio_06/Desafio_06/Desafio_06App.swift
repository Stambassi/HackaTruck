//
//  Desafio_06App.swift
//  Desafio_06
//
//  Created by Turma02-5 on 21/03/25.
//

import SwiftUI

@main
struct Desafio_06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
