//
//  ContentView.swift
//  Desafio_06
//
//  Created by Turma02-5 on 21/03/25.
//

import SwiftUI

struct PinkButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(width: 200, height: 75)
            .background(.pink)
            .cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/)
            .foregroundStyle(.white)
            .bold()
    }
}

struct SheetView: View{
    @Environment(\.dismiss) var dismiss
    
    var body: some View{
        ZStack{
            Color.fundo.ignoresSafeArea()
            VStack{
                Text("Sheet View")
                    .font(.title)
                    .foregroundStyle(.white)
                    .bold()
                    .padding()
                
                Spacer()
                VStack{
                    Text("Nome: Augusto")
                        .foregroundStyle(.white)
                        .font(.title2)
                    Text("Sobrenome: Stambassi")
                        .foregroundStyle(.white)
                        .font(.title2)
                }
                .frame(width: 250,height: 150)
                .background(.pink)
                .cornerRadius(10.0)
                
                Spacer()
            }
        
        }
    }
}

struct ContentView: View {
    @State private var showingSheet = false
    var body: some View {
        NavigationStack{
            ZStack{
                Color.fundo.ignoresSafeArea()
                VStack {
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .containerRelativeFrame(.horizontal) { size, axis in
                                size * 0.8
                            }
                        .padding()
                        .colorMultiply(.black)
                        .colorInvert()
                    
                    Spacer()
                    
                    NavigationLink(destination: Modo1View()){
                        Text("Modo 1")
                            .frame(width: 200, height: 75)
                            .background(.pink)
                            .cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                            .bold()
                    }
                    
                    NavigationLink(destination: Modo2View()){
                        Text("Modo 2")
                            .frame(width: 200, height: 75)
                            .background(.pink)
                            .cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                            .bold()
                    }
                    
                    Button("Modo 3"){
                        showingSheet.toggle()
                    }
                    .buttonStyle(PinkButton())
                    .sheet(isPresented: $showingSheet) {
                        SheetView()
                    }
                    Spacer()
                    
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
