//
//  Modo2b.swift
//  Desafio_06
//
//  Created by Turma02-5 on 21/03/25.
//

import Foundation
import SwiftUI

struct Modo2bView: View {
    @Binding var nome: String
    var body: some View {
        ZStack{
            Color.fundo.ignoresSafeArea()
            VStack{
                Text("Modo 2")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundStyle(.white)
                    .padding()
                    .bold()
                
                Spacer()
                
                VStack{
                    Text("Volte, \(nome)")
                        .foregroundStyle(.white)
                        .font(.title2)
                        .bold()
                }
                .frame(width: 175,height: 100)
                .background(.pink)
                .cornerRadius(10.0)

            
                Spacer()
                
            }
        }
    }
}


