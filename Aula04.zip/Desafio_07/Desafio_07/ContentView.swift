//
//  ContentView.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import SwiftUI


struct Song : Identifiable {
    var id : Int
    var name : String
    var artist : String
    var capa : String
}

struct Config : Identifiable {
    var id : Int
    var name : String
    var image : String
    var author : String
    var authorIcon : String
}

var all_playlists : [[Song]] = [
    [
        Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://picsum.photos/256"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://picsum.photos/256"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://picsum.photos/256"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://picsum.photos/256"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://picsum.photos/256"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://picsum.photos/256"),
    ],
    [
        Song(id: 0, name: "Ser bandido é bom demais", artist: "Dj Ramon Sucesso, Mc Kaio", capa: "https://picsum.photos/256"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://picsum.photos/256"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://picsum.photos/256"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://picsum.photos/256"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://picsum.photos/256"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://picsum.photos/256"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://picsum.photos/256"),
    ],
    [
        Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 4, name: "I don't Care", artist: "VIOLENT VIRA", capa: "https://picsum.photos/256"),
        Song(id: 5, name: "Rollin'(Air Raid Vehicle)", artist: "Limp Bizkit", capa: "https://picsum.photos/256"),
        Song(id: 6, name: "Given up", artist: "Linkin park", capa: "https://picsum.photos/256"),
        Song(id: 7, name: "Change(In the House of Flies)", artist: "Deftones", capa: "https://picsum.photos/256"),
        Song(id: 8, name: "R U Mine?", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 9, name: "Seventh Heaven", artist: "INOHA", capa: "https://picsum.photos/256"),
        Song(id: 10, name: "No. 1 Party Anthem", artist: "Arctic Monkeys", capa: "https://picsum.photos/256"),
        Song(id: 11, name: "Two Faced", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 12, name: "Heavy Is the Crown", artist: "Linkin Park", capa: "https://picsum.photos/256"),
        Song(id: 13, name: "NEW WEST ORDER", artist: "FEVER 333", capa: "https://picsum.photos/256"),
    ]]


var sugeridos : [Config] = [Config(id: 0, name:"Indie & Metal", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
    Config(id: 1, name:"RAVE FUNK", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
    Config(id: 2, name:"Tudo", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"),
]

struct ContentView: View {
    var body: some View {
        TemplatePlaylistView(playlist: all_playlists[0], playlist_config: sugeridos[0])
    }
}

#Preview {
    ContentView()
}
