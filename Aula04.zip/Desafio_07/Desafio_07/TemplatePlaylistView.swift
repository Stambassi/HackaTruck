//
//  TemplatePlaylistView.swift
//  Desafio_07
//
//  Created by Turma02-5 on 24/03/25.
//

import SwiftUI

struct TemplatePlaylistView: View {
    
    @State var playlist : [Song]
    @State var playlist_config : Config
  
    var body: some View {
     
        NavigationStack {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.purple, .black]),startPoint: .top, endPoint: .bottom).ignoresSafeArea()
                ScrollView(.vertical, showsIndicators: false) {
                    VStack{
                        AsyncImage(url:URL(string:playlist_config.image))
                            .padding(.top)
                        VStack(alignment: .leading, spacing: 20){
                            Text(playlist_config.name)
                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                .foregroundStyle(.white)
                                .multilineTextAlignment(.trailing)
                            
                            HStack{
                                AsyncImageView(urlEntrada: playlist_config.authorIcon)
                                    .frame(width: 20,height: 20)
                                Text(playlist_config.author)
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                    .multilineTextAlignment(.trailing)
                            }
                        }.frame(width: 380, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading).padding(.leading)
                        
                        
                        ForEach(playlist){ musica in
                            NavigationLink(destination: MusicaView(musica: musica)){
                                HStack{
                                    AsyncImageView(urlEntrada: musica.capa)
                                        .frame(width: 40 ,height: 40)
                                    //                            .padding(.leading)
                                    VStack(alignment: .leading){
                                        Text(musica.name)
                                            .font(.headline)
                                            .foregroundStyle(.white)
                                        
                                        Text(musica.artist)
                                            .font(.caption)
                                            .foregroundStyle(.white)
                                    }
                                    Spacer()
                                    Image(systemName: "ellipsis")
                                        .foregroundStyle(.white)
                                        .padding()
                                }.padding(.bottom)
                            }
                        }
                        
                        Text("Sugeridos")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                            .frame(width: 200,height: 100,alignment: .leading)
                        
                        ScrollView(.horizontal, showsIndicators: false){
                            HStack{
                                ForEach(sugeridos){ sugestao in
                                    let idAtual = playlist_config.id
                                    if(idAtual != sugestao.id){
                                        NavigationLink(destination: TemplatePlaylistView(playlist: all_playlists[sugestao.id], playlist_config: sugestao)){
                                            VStack(alignment: .center){
                                                AsyncImageView(urlEntrada: sugestao.image)
                                                    .frame(width: 200,height: 200)
                                                Text(sugestao.name)
                                                    .font(.headline)
                                                    .foregroundStyle(.white)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
            }
        }.tint(.white)
            .navigationBarBackButtonHidden()
    }
}

#Preview {
    TemplatePlaylistView(playlist: [
        Song(id: 0, name: "Yougest Daughter", artist: "Superheaven", capa: "https://i.scdn.co/image/ab67616d00001e02aa28c876738d3ae18c1d8e2f"),
        Song(id: 1, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256"),
        Song(id: 2, name: "Knife Party", artist: "Deftones", capa: "."),
        Song(id: 3, name: "Goalkeeper", artist: "Chinese Football", capa: "https://picsum.photos/256")] ,playlist_config: Config(id: 0, name:"Indie & Metal", image: "https://picsum.photos/256", author: "Augustin",authorIcon: "https://picsum.photos/256"))
}
